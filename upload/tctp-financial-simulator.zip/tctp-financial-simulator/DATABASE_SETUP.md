# DATABASE_SETUP.md — TCTP Financial Simulator

## Prerequisites

- **MySQL 8.0+** installed and running
- A MySQL user with `CREATE DATABASE`, `CREATE TABLE`, and `INSERT` privileges
- MySQL CLI (`mysql`) available in your PATH

## Step 1: Create the Database and Tables

Open your terminal and run:

```bash
mysql -u root -p < database/schema.sql
```

This will:
1. Create the `tctp_simulator` database (if it doesn't exist)
2. Create all required tables: `users`, `projects`, `cost_items`, `time_logs`, `export_history`
3. Set up foreign key constraints and indexes

## Step 2: Seed Demo Data

```bash
mysql -u root -p tctp_simulator < database/seed.sql
```

This will populate the database with:

### Demo Users

| Username | Password   | Email            | Role  |
|----------|------------|------------------|-------|
| `demo`   | `demo1234` | demo@tctp.local  | admin |
| `admin`  | `admin1234`| admin@tctp.local | admin |

> **Important:** The passwords above are bcrypt-hashed in the seed SQL. The hashes were pre-generated. If you need to change passwords, use an online bcrypt tool or a Node.js script:
>
> ```js
> const bcrypt = require('bcryptjs');
> const hash = bcrypt.hashSync('your-password', 12);
> console.log(hash);
> ```

### Demo Project: "AI-Powered SaaS Platform"

A realistic 12-month SaaS project with:

**Labour (6 roles):**
| Role | Rate Basis | Rate | Qty |
|------|-----------|------|-----|
| Senior Full-Stack Developer | Monthly | $8,500 | 2 |
| Mid-Level Backend Developer | Monthly | $6,000 | 1 |
| UI/UX Designer | Monthly | $5,500 | 1 |
| DevOps Engineer | Hourly | $7,000 | 1 (160 hrs/mo) |
| QA Engineer | Monthly | $4,500 | 1 |
| Project Manager | Monthly | $6,500 | 1 |

**Infrastructure (6 items):** AWS EC2, RDS MySQL, CloudFront CDN, S3, Domain/SSL, CloudWatch

**APIs (5 items):** Stripe, SendGrid, Twilio, Auth0, Google Maps

**LLM/AI (3 items):** GPT-4o API, Embedding Model, Pinecone Vector DB

**Overhead (4 items):** Office, Software Licenses, Legal, Marketing

**Time Tracking Data:** 3 months of actual hours logged for all 6 labour resources, with realistic variances (some ahead, some behind schedule).

## Database Schema Overview

```
┌─────────────┐     ┌──────────────┐     ┌────────────┐
│   users     │────<│   projects   │────<│ cost_items │
│             │     │              │     │            │
│ id          │     │ id           │     │ id         │
│ username    │     │ user_id (FK) │     │ project_id │
│ email       │     │ name         │     │ category   │
│ password_   │     │ currency     │     │ description│
│   hash      │     │ duration     │     │ cost_type  │
│ full_name   │     │ target_volume│     │ rate       │
│ role        │     │ target_margin│     │ quantity   │
└─────────────┘     │ current_month│     │ rate_basis │
                    │ ...          │     │ planned_   │
                    └──────────────┘     │   hours    │
                                         └─────┬──────┘
                                               │
                                         ┌─────▼──────┐
                                         │ time_logs  │
                                         │            │
                                         │ cost_item_ │
                                         │   id (FK)  │
                                         │ month      │
                                         │ actual_    │
                                         │   hours    │
                                         └────────────┘
```

## Verifying the Setup

Connect to MySQL and verify:

```bash
mysql -u root -p tctp_simulator
```

```sql
-- Check tables
SHOW TABLES;

-- Check user count
SELECT COUNT(*) AS user_count FROM users;

-- Check project count
SELECT COUNT(*) AS project_count FROM projects;

-- Check cost items
SELECT category, COUNT(*) AS items, SUM(rate * quantity) AS total_rate
FROM cost_items GROUP BY category;

-- Check time logs
SELECT COUNT(*) AS log_count FROM time_logs;

-- Quick cost summary
SELECT
  ci.category,
  ci.cost_type,
  ci.description,
  ci.rate,
  ci.quantity,
  ci.rate_basis,
  ci.planned_hours,
  (ci.rate * ci.quantity) AS line_total
FROM cost_items ci
WHERE ci.project_id = 1
ORDER BY ci.category, ci.sort_order;
```

## Troubleshooting

### "Access denied for user"
```bash
# Make sure you're using the correct MySQL user and password
mysql -u root -p
# Then manually run: source database/schema.sql;
```

### "Unknown database 'tctp_simulator'"
The schema.sql creates the database automatically. If you get this error running seed.sql, make sure schema.sql ran successfully first.

### Foreign key constraint errors
The tables must be created in order (users → projects → cost_items → time_logs). The schema.sql handles this order automatically.

### Reset the database
```bash
mysql -u root -p -e "DROP DATABASE IF EXISTS tctp_simulator;"
mysql -u root -p < database/schema.sql
mysql -u root -p tctp_simulator < database/seed.sql
```