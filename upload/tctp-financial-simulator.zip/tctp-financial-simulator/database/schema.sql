-- ============================================================
-- TCTP Software Financial Simulator — Database Schema
-- Compatible with MySQL 8.0+
-- ============================================================

CREATE DATABASE IF NOT EXISTS tctp_simulator
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE tctp_simulator;

-- ── Users ──────────────────────────────────────────────────
CREATE TABLE users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(50)  NOT NULL UNIQUE,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  full_name     VARCHAR(100) DEFAULT '',
  role          ENUM('admin','viewer') NOT NULL DEFAULT 'admin',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── Projects ───────────────────────────────────────────────
CREATE TABLE projects (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id         INT UNSIGNED NOT NULL,
  name            VARCHAR(200) NOT NULL DEFAULT 'Untitled Project',
  description     TEXT,
  currency        VARCHAR(10)  NOT NULL DEFAULT '$',
  unit_label      VARCHAR(50)  NOT NULL DEFAULT 'Units',
  duration        INT UNSIGNED NOT NULL DEFAULT 12,
  target_volume   DECIMAL(14,2) NOT NULL DEFAULT 500,
  sales_period    INT UNSIGNED NOT NULL DEFAULT 12,
  target_margin   DECIMAL(5,2) NOT NULL DEFAULT 35.00,
  churn_rate      DECIMAL(5,2) NOT NULL DEFAULT 3.00,
  growth_rate     DECIMAL(5,2) NOT NULL DEFAULT 10.00,
  cost_buffer     DECIMAL(5,2) NOT NULL DEFAULT 15.00,
  min_roi         DECIMAL(5,2) NOT NULL DEFAULT 15.00,
  max_payback     INT UNSIGNED NOT NULL DEFAULT 36,
  min_margin      DECIMAL(5,2) NOT NULL DEFAULT 20.00,
  selling_price   DECIMAL(14,2) DEFAULT NULL,
  current_month   INT UNSIGNED NOT NULL DEFAULT 3,
  is_active       TINYINT(1)   NOT NULL DEFAULT 1,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── Cost Items ─────────────────────────────────────────────
CREATE TABLE cost_items (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_id  INT UNSIGNED NOT NULL,
  category    ENUM('labour','infra','apis','llm','overhead') NOT NULL,
  description VARCHAR(300) NOT NULL DEFAULT '',
  cost_type   ENUM('monthly','onetime','perunit') NOT NULL DEFAULT 'monthly',
  rate        DECIMAL(14,4) NOT NULL DEFAULT 0,
  quantity    DECIMAL(10,2) NOT NULL DEFAULT 1,
  rate_basis  ENUM('monthly','hourly') NOT NULL DEFAULT 'monthly',
  planned_hours DECIMAL(8,2) DEFAULT NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  INDEX idx_project_category (project_id, category)
) ENGINE=InnoDB;

-- ── Time Tracking Logs (actual hours per resource per month) ──
CREATE TABLE time_logs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cost_item_id INT UNSIGNED NOT NULL,
  month       INT UNSIGNED NOT NULL,
  actual_hours DECIMAL(8,2) NOT NULL DEFAULT 0,
  notes       VARCHAR(500) DEFAULT '',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (cost_item_id) REFERENCES cost_items(id) ON DELETE CASCADE,
  UNIQUE KEY uk_item_month (cost_item_id, month)
) ENGINE=InnoDB;

-- ── Export History (optional audit) ────────────────────────
CREATE TABLE export_history (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  project_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  format      ENUM('xlsx','pptx','pdf') NOT NULL,
  file_name   VARCHAR(255),
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;