-- ============================================================
-- TCTP Software Financial Simulator — Seed Data
-- Run this AFTER schema.sql
-- ============================================================

USE tctp_simulator;

-- ── Demo User ──────────────────────────────────────────────
-- Password: "demo1234" (bcrypt hash)
INSERT INTO users (username, email, password_hash, full_name, role)
VALUES (
  'demo',
  'demo@tctp.local',
  '$2b$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36Kz2Ln0G4sVn1YB3qX9V2G',
  'Demo User',
  'admin'
);

-- ── Admin User ─────────────────────────────────────────────
-- Password: "admin1234" (bcrypt hash)
INSERT INTO users (username, email, password_hash, full_name, role)
VALUES (
  'admin',
  'admin@tctp.local',
  '$2b$10$YQf8bRPAjZ1T6l5qH0HnHOaL3iJ0g8cX7wUv5kN3mQ1r2s3t4u5v',
  'Admin User',
  'admin'
);

-- ── Demo Project ───────────────────────────────────────────
INSERT INTO projects (
  user_id, name, description,
  currency, unit_label, duration, target_volume, sales_period,
  target_margin, churn_rate, growth_rate, cost_buffer,
  min_roi, max_payback, min_margin, selling_price, current_month
) VALUES (
  1,
  'AI-Powered SaaS Platform',
  'Full-stack SaaS application with AI/ML features, cloud infrastructure, and third-party API integrations.',
  '$', 'Subscriptions', 12, 500, 12,
  35.00, 3.00, 10.00, 15.00,
  15.00, 36, 20.00, NULL, 3
);

-- ── Cost Items: Labour ─────────────────────────────────────
INSERT INTO cost_items (project_id, category, description, cost_type, rate, quantity, rate_basis, planned_hours, sort_order) VALUES
(1, 'labour', 'Senior Full-Stack Developer',   'monthly', 8500,  2, 'monthly', NULL, 1),
(1, 'labour', 'Mid-Level Backend Developer',    'monthly', 6000,  1, 'monthly', NULL, 2),
(1, 'labour', 'UI/UX Designer',                 'monthly', 5500,  1, 'monthly', NULL, 3),
(1, 'labour', 'DevOps Engineer',                'monthly', 7000,  1, 'hourly',  160, 4),
(1, 'labour', 'QA Engineer',                    'monthly', 4500,  1, 'monthly', NULL, 5),
(1, 'labour', 'Project Manager',                'monthly', 6500,  1, 'monthly', NULL, 6);

-- ── Cost Items: Infrastructure ─────────────────────────────
INSERT INTO cost_items (project_id, category, description, cost_type, rate, quantity, rate_basis, planned_hours, sort_order) VALUES
(1, 'infra', 'AWS EC2 (Production)',            'monthly', 320,   1, 'monthly', NULL, 1),
(1, 'infra', 'AWS RDS MySQL db.t3.medium',      'monthly', 180,   1, 'monthly', NULL, 2),
(1, 'infra', 'CloudFront CDN',                  'monthly', 45,    1, 'monthly', NULL, 3),
(1, 'infra', 'S3 Storage (500 GB)',              'monthly', 12,    1, 'monthly', NULL, 4),
(1, 'infra', 'Domain + SSL Certificate',        'onetime',  75,    1, 'monthly', NULL, 5),
(1, 'infra', 'AWS CloudWatch Monitoring',       'monthly', 30,    1, 'monthly', NULL, 6);

-- ── Cost Items: APIs ───────────────────────────────────────
INSERT INTO cost_items (project_id, category, description, cost_type, rate, quantity, rate_basis, planned_hours, sort_order) VALUES
(1, 'apis', 'Stripe Payment Processing',        'perunit', 0.29,   1, 'monthly', NULL, 1),
(1, 'apis', 'SendGrid Email API',               'monthly', 90,    1, 'monthly', NULL, 2),
(1, 'apis', 'Twilio SMS Notifications',         'perunit', 0.05,   1, 'monthly', NULL, 3),
(1, 'apis', 'Auth0 Authentication',             'monthly', 55,    1, 'monthly', NULL, 4),
(1, 'apis', 'Google Maps API',                  'monthly', 200,   1, 'monthly', NULL, 5);

-- ── Cost Items: LLM / AI ──────────────────────────────────
INSERT INTO cost_items (project_id, category, description, cost_type, rate, quantity, rate_basis, planned_hours, sort_order) VALUES
(1, 'llm', 'GPT-4o API Calls (est. 50K tokens/day)', 'monthly', 1200, 1, 'monthly', NULL, 1),
(1, 'llm', 'Embedding Model (text-embedding-3-small)', 'monthly', 150,  1, 'monthly', NULL, 2),
(1, 'llm', 'Vector DB (Pinecone)',             'monthly', 70,    1, 'monthly', NULL, 3);

-- ── Cost Items: Overhead ──────────────────────────────────
INSERT INTO cost_items (project_id, category, description, cost_type, rate, quantity, rate_basis, planned_hours, sort_order) VALUES
(1, 'overhead', 'Office Space / Co-working',   'monthly', 800,   1, 'monthly', NULL, 1),
(1, 'overhead', 'Software Licenses (GitHub, Figma, Jira)', 'monthly', 120, 1, 'monthly', NULL, 2),
(1, 'overhead', 'Legal & Compliance',           'onetime',  3000,  1, 'monthly', NULL, 3),
(1, 'overhead', 'Marketing (Initial Campaign)',  'onetime',  5000,  1, 'monthly', NULL, 4);

-- ── Time Logs (actual hours for first 3 months) ───────────
-- Senior Full-Stack Dev (2 people) — slightly ahead
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(1, 1, 165), (1, 2, 172), (1, 3, 170);

-- Mid-Level Backend Dev — on track
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(2, 1, 160), (2, 2, 160), (2, 3, 158);

-- UI/UX Designer — slightly over (extra iteration)
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(3, 1, 170), (3, 2, 180), (3, 3, 175);

-- DevOps Engineer (hourly, 160 planned) — over in month 2
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(4, 1, 160), (4, 2, 185), (4, 3, 178);

-- QA Engineer — under (ramp-up)
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(5, 1, 140), (5, 2, 150), (5, 3, 155);

-- Project Manager — over (extra meetings)
INSERT INTO time_logs (cost_item_id, month, actual_hours) VALUES
(6, 1, 168), (6, 2, 175), (6, 3, 172);